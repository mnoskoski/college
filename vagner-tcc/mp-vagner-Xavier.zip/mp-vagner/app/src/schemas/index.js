const validatePost = require('./validatePost');

module.exports = {
    validatePost
}