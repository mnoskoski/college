const express = require('express');
const router = express.Router();

const log = require('./middleware/initLog');
const credit = require('./resource/credit/index');
const responseMW = require('./middleware/responseMW');
const schema = require('./schemas/index');

router.post('/first-steps',
            log.initLog,
            schema.validatePost,
            credit.post,
            responseMW.validResponse
      );

router.get('/server-error',
      log.initLog,
      responseMW.invalidResponse
);

router.get('/server-error/:errorMessage',
      log.initLog,
      responseMW.invalidResponse
);



module.exports = router;
